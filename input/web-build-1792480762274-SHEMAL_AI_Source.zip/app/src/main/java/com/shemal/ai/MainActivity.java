package com.shemal.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText input;
    private TextView response;
    private TextToSpeech tts;
    private static final int REQ_SPEECH = 41;
    private static final int REQ_MIC = 42;
    private int bg = Color.rgb(12, 18, 32);
    private int panel = Color.rgb(25, 35, 54);
    private int accent = Color.rgb(75, 156, 255);
    private int white = Color.WHITE;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("bn", "BD"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("bn", "IN"));
                }
            }
        });
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(white); t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(white);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("SHEMAL AI", 30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView subtitle = text("তোমার বাংলা AI সহকারী", 17);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(40)));

        TextView welcome = text("আসসালামু আলাইকুম! নিচে লিখে প্রশ্ন করো, মাইক্রোফোনে কথা বলো অথবা ওয়েবে খোঁজ করো।", 17);
        welcome.setPadding(dp(14), dp(14), dp(14), dp(14));
        welcome.setBackgroundTintList(null);
        welcome.setBackgroundColor(panel);
        root.addView(welcome, new LinearLayout.LayoutParams(-1, -2));

        input = new EditText(this);
        input.setHint("এখানে বাংলায় লিখো…");
        input.setTextColor(white);
        input.setHintTextColor(Color.LTGRAY);
        input.setTextSize(17);
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(20);
        root.addView(input, ip);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button mic = button("🎙 কথা বলো");
        Button search = button("🔎 ওয়েবে খোঁজো");
        row.addView(mic, new LinearLayout.LayoutParams(0, dp(54), 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(54), 1);
        sp.leftMargin = dp(8);
        row.addView(search, sp);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(12);
        root.addView(row, rp);

        response = text("এখানে তোমার ফলাফল দেখানো হবে।", 16);
        response.setGravity(Gravity.TOP);
        response.setPadding(dp(14), dp(14), dp(14), dp(14));
        response.setBackgroundColor(panel);
        LinearLayout.LayoutParams res = new LinearLayout.LayoutParams(-1, -2);
        res.topMargin = dp(18);
        root.addView(response, res);

        Button speak = button("🔊 উত্তর পড়ে শোনাও");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.topMargin = dp(12);
        root.addView(speak, bp);

        mic.setOnClickListener(v -> startListening());
        search.setOnClickListener(v -> webSearch());
        speak.setOnClickListener(v -> {
            String s = response.getText().toString();
            if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "shemal-answer");
        });
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "এই ফোনে speech recognition সেবা পাওয়া যাচ্ছে না। Google app বা speech service চালু করো।", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলো");
            startActivityForResult(intent, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Speech service পাওয়া যায়নি।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                input.setText(results.get(0));
                webSearch();
            }
        }
    }

    private void webSearch() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "আগে কিছু লিখো বা মাইক্রোফোনে বলো।", Toast.LENGTH_SHORT).show();
            return;
        }
        response.setText("ওয়েবে খোঁজা হচ্ছে: " + q + "\n\nব্রাউজারে সার্চ ফলাফল খুলবে।");
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "ব্রাউজার খোলা যায়নি।", Toast.LENGTH_LONG).show();
        }
        if (tts != null) tts.speak("তোমার প্রশ্নটি ওয়েবে খুঁজছি", TextToSpeech.QUEUE_FLUSH, null, "shemal-search");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_MIC && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else if (requestCode == REQ_MIC) Toast.makeText(this, "কথা শোনার জন্য মাইক্রোফোন অনুমতি দরকার।", Toast.LENGTH_LONG).show();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
