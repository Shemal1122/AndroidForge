# SHEMAL AI — Android source project

A simple Android app with Bengali text-to-speech, speech recognition, and web search.

## Build
This project uses a standard Android Gradle layout. Upload the ZIP to AndroidForge and select Android (APK), build variant `auto`.

## Features
- Bengali-first interface
- Tap microphone to use Android speech recognition (availability depends on the device's speech service and language pack)
- Bengali text-to-speech
- Search the web through the device browser
- No paid API key required

## Notes
- This is a starter app, not a cloud AI model. It does not provide ChatGPT-like generative answers offline.
- Speech recognition and speech synthesis use Android's installed services and may require internet or Bengali language data.
- Web search opens a browser/search page; it does not scrape or summarize websites inside the app.
