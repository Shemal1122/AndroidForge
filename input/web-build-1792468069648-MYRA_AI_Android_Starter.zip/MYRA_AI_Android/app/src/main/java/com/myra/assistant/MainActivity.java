package com.myra.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 101;
    private static final int REQ_AUDIO = 102;
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF101329);
        getWindow().setNavigationBarColor(0xFF101329);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.setBackgroundColor(0xFFF5F6FC);

        TextView title = new TextView(this);
        title.setText("MYRA AI  ✦");
        title.setTextSize(25);
        title.setTextColor(0xFF22234A);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(8));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("তোমার ব্যক্তিগত বাংলা সহকারী");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF656780);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        scroll = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(dp(4), dp(4), dp(4), dp(12));
        scroll.addView(messages);
        root.addView(scroll, scrollParams);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(16);
        input.setHint("বাংলায় লিখো বা মাইকে বলো…");
        searchRow.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button send = new Button(this);
        send.setText("পাঠাও");
        searchRow.addView(send);
        root.addView(searchRow);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button mic = new Button(this);
        mic.setText("🎙 কথা বলো");
        Button web = new Button(this);
        web.setText("🔎 ওয়েব সার্চ");
        actions.addView(mic, new LinearLayout.LayoutParams(0, dp(52), 1f));
        actions.addView(web, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(actions);
        setContentView(root);

        addMessage("MYRA", "হ্যালো! আমি MYRA AI। বাংলায় প্রশ্ন করো, অথবা ওয়েব সার্চ ব্যবহার করো।");
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("bn", "BD"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                           result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        send.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (!q.isEmpty()) { input.setText(""); handleQuery(q); }
        });
        mic.setOnClickListener(v -> startVoice());
        web.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (q.isEmpty()) q = "বাংলা";
            input.setText("");
            searchWeb(q);
        });
    }

    private void handleQuery(String q) {
        addMessage("তুমি", q);
        String lower = q.toLowerCase(Locale.ROOT);
        String answer;
        if (lower.contains("হ্যালো") || lower.contains("হাই") || lower.contains("hello")) {
            answer = "হ্যালো! কেমন আছো? কীভাবে সাহায্য করতে পারি?";
        } else if (lower.contains("তোমার নাম") || lower.contains("নাম কি")) {
            answer = "আমার নাম MYRA AI। আমি তোমার বাংলা ব্যক্তিগত সহকারী।";
        } else if (lower.contains("সময়") || lower.contains("সময়")) {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("hh:mm a", new Locale("bn", "BD"));
            answer = "এখন সময় " + sdf.format(new java.util.Date()) + "।";
        } else if (lower.contains("খুঁজে") || lower.contains("সার্চ") || lower.contains("search")) {
            searchWeb(q);
            answer = "তোমার প্রশ্নের জন্য ওয়েব সার্চ খুলে দিয়েছি।";
        } else {
            answer = "আমি এখন প্রাথমিক সংস্করণে আছি। আরও তথ্যের জন্য “ওয়েব সার্চ” বোতাম চাপো, অথবা প্রশ্নটি লিখে পাঠাও।";
        }
        addMessage("MYRA", answer);
        speak(answer);
    }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলো");
            startActivityForResult(intent, REQ_SPEECH);
        } catch (Exception e) {
            Toast.makeText(this, "এই ফোনে ভয়েস ইনপুট সেবা পাওয়া যাচ্ছে না।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) handleQuery(results.get(0));
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoice();
        else if (requestCode == REQ_AUDIO) Toast.makeText(this, "ভয়েস ব্যবহারে মাইক্রোফোন অনুমতি লাগবে।", Toast.LENGTH_LONG).show();
    }

    private void searchWeb(String q) {
        try {
            String url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8");
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "ওয়েব সার্চ খোলা যায়নি।", Toast.LENGTH_LONG).show();
        }
    }

    private void speak(String text) {
        if (ttsReady && tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myra_reply");
    }

    private void addMessage(String who, String text) {
        TextView bubble = new TextView(this);
        bubble.setText(who + "\n" + text);
        bubble.setTextSize(16);
        bubble.setTextColor(0xFF20213D);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));
        bubble.setBackgroundColor(who.equals("MYRA") ? 0xFFE5E7FF : 0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        messages.addView(bubble, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
