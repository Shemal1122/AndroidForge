# MYRA AI — Android starter project

এটি MYRA AI-এর প্রাথমিক Android Studio সোর্স প্রজেক্ট।

## এতে যা আছে
- বাংলা টেক্সট চ্যাটের সহজ ইন্টারফেস
- Android Speech Recognizer দিয়ে বাংলা ভয়েস ইনপুট (ফোনে সমর্থিত speech service লাগবে)
- Android Text-to-Speech দিয়ে বাংলা উত্তর পড়ে শোনানোর চেষ্টা (বাংলা voice data ফোনে না থাকলে কাজ নাও করতে পারে)
- Google Web Search-এ প্রশ্ন খোলা
- মাইক্রোফোন অনুমতি চাওয়া

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই সংস্করণে পূর্ণাঙ্গ AI মডেল/API যুক্ত নেই। কিছু সাধারণ উত্তর স্থানীয়ভাবে দেওয়া হয়; বাকি প্রশ্নের জন্য Web Search খুলতে হবে।
- Google search/voice recognition-এর জন্য ইন্টারনেট ও ফোনে সংশ্লিষ্ট পরিষেবা প্রয়োজন হতে পারে।
- এটি সোর্স প্রজেক্ট, প্রস্তুত APK নয়। এই পরিবেশে Android SDK দিয়ে APK compile/test করা হয়নি।

## APK বানানোর সহজ উপায়
1. কম্পিউটারে Android Studio ইনস্টল করো।
2. এই ZIP ফাইল extract করে Android Studio-তে `MYRA_AI_Android` ফোল্ডারটি Open করো।
3. Gradle sync শেষ হতে দাও। প্রয়োজনে Android SDK Platform 35 ইনস্টল করো।
4. `Build > Build APK(s)` বেছে নাও।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।
6. APK ফোনে পাঠিয়ে ইনস্টল করার আগে Android-এর অনুমতি অনুযায়ী “Install unknown apps” চালু করতে হতে পারে।

## ফ্রি রাখার বিষয়ে
এই starter project-এর নিজস্ব API key বা paid AI service দরকার নেই। তবে এটি এখনো ChatGPT-র মতো পূর্ণাঙ্গ AI নয়। পরে ফ্রি/কম-খরচের AI backend যোগ করতে হলে সেই সেবার বর্তমান সীমা, গোপনীয়তা ও খরচ যাচাই করতে হবে। API key কখনো APK-এর মধ্যে hard-code কোরো না।
